const trueValues = [true, 1, "true", "1"];

export const checkIsTrue = (value: any) => trueValues.includes(value);
