export const activeOrderStatuses = ["new", "accepted", "ready", "on_a_way"];
export const orderHistoryStatuses = ["delivered", "canceled"];
