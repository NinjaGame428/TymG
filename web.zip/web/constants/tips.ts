export const tipPercents = [5, 10, 15, 20, 25];

export const tipFor = ["system", "driver"];
