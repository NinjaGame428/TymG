export const STORY_DURATION = 10;
